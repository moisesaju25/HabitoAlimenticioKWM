﻿Imports MySql.Data.MySqlClient

Public Class Login
    Public Shared _FECHA As Date

    Public Shared Property FECHA As Date
        Get
            Return _FECHA
        End Get
        Set(value As Date)
            _FECHA = value
        End Set
    End Property

    Public Shared Function Buscar(ByVal cadena As String) As Boolean
        Try
            AbrirConexion()

            If ConexionMySQL.State = ConnectionState.Closed Then
                ConexionMySQL.Open()
            End If

            Configuracion.ObtenerFechaServidor()
            Comando = New MySqlCommand(cadena, ConexionMySQL)
            'Comando.Parameters.Add("?FECHA", MySqlDbType.DateTime).Value = FECHA
            adaptador = New MySqlDataAdapter(Comando)

            ds = New DataSet
            adaptador.Fill(ds)

            If ds.Tables(0).Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If

            ConexionMySQL.Close()
        Catch ex As Exception
            Console.WriteLine(Err.Description)
            Return False
        End Try

    End Function

    Public Shared Sub SaveData(ByVal Cadena As String)
        Using connection As New MySqlConnection(cadenaConexion)
            Dim command As New MySqlCommand(Cadena, connection)
            command.Connection.Open()
            command.Parameters.Add("?FECHA", MySqlDbType.DateTime).Value = FECHA
            command.ExecuteNonQuery()
        End Using
    End Sub
End Class
