﻿Public Class frmInicio
    Private Sub ConsultaPacientesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultaPacientesToolStripMenuItem.Click
        frmConsultaPaciente.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class