﻿Imports System.Text

Public Class frmLogin
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        'try catch nos permite controlar los errores que pueden producirse al intentar ingresar al sistema
        Try
            If txtUsuario.Text = "" Then
                MessageBox.Show("Debe ingresar un usuario válido", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtUsuario.Focus()
            Else
                If txtPassword.Text = "" Then
                    MessageBox.Show("Debe ingresar una contraseña válida", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    txtPassword.Focus()
                    txtPassword.Select()
                Else
                    If Login.Buscar("select * from usuario where usuario = '" & txtUsuario.Text & "' and  clave = '" & txtPassword.Text & "'") = True Then
                        'MessageBox.Show("Correcto", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        'DataGridView1.DataSource = ds.Tables(0)
                        frmInicio.Show()
                        Me.Hide()
                        Console.WriteLine(ds.Tables(0))
                    Else
                        MessageBox.Show("Usuario o Contraseña incorrectas, por favor intente nuevamente", "Información", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        txtPassword.Text = ""
                        'DataGridView1.DataSource = Nothing
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(Err.Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ConsultaDatos()
        If txtUsuario.Text.Length = 0 Then
            If Login.Buscar("select * from datos limit 50") = True Then
                'DataGridView1.DataSource = ds.Tables(0)
            Else
                'DataGridView1.DataSource = Nothing
            End If
        Else

        End If
        If Login.Buscar("select * from datos where UPPER(nombre) like '%" & UCase(txtUsuario.Text) & "%'") = True Then
            'DataGridView1.DataSource = ds.Tables(0)
        Else
            'DataGridView1.DataSource = Nothing
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'habilita codificacion si se omite este registro no permite insert o consulta de la información en la base de datos
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance)
        'Configuracion.ObtenerFechaServidor()
        'Try

        'Me.Text = "Fecha y hora local: " & Configuracion.FECHASERVIDOR.Date.ToString("dd-MMM-yyyy") & " " & Configuracion.FECHASERVIDOR.TimeOfDay.ToString
        'Catch ex As Exception
        'MessageBox.Show(Err.Description, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try
    End Sub
End Class
