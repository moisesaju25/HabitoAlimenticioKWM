﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnSalir = New Button()
        Label1 = New Label()
        Label2 = New Label()
        txtUsuario = New TextBox()
        txtPassword = New TextBox()
        btnIngresar = New Button()
        Label3 = New Label()
        SuspendLayout()
        ' 
        ' btnSalir
        ' 
        btnSalir.Location = New Point(63, 394)
        btnSalir.Name = "btnSalir"
        btnSalir.Size = New Size(206, 81)
        btnSalir.TabIndex = 0
        btnSalir.Text = "Salir"
        btnSalir.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(63, 125)
        Label1.Name = "Label1"
        Label1.Size = New Size(94, 32)
        Label1.TabIndex = 1
        Label1.Text = "Usuario"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(63, 256)
        Label2.Name = "Label2"
        Label2.Size = New Size(134, 32)
        Label2.TabIndex = 2
        Label2.Text = "Contraseña"
        ' 
        ' txtUsuario
        ' 
        txtUsuario.Location = New Point(63, 171)
        txtUsuario.Name = "txtUsuario"
        txtUsuario.Size = New Size(448, 39)
        txtUsuario.TabIndex = 3
        ' 
        ' txtPassword
        ' 
        txtPassword.Location = New Point(63, 312)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(462, 39)
        txtPassword.TabIndex = 4
        ' 
        ' btnIngresar
        ' 
        btnIngresar.Location = New Point(319, 394)
        btnIngresar.Name = "btnIngresar"
        btnIngresar.Size = New Size(206, 81)
        btnIngresar.TabIndex = 5
        btnIngresar.Text = "Ingresar"
        btnIngresar.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Arial", 18F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(13, 21)
        Label3.Name = "Label3"
        Label3.Size = New Size(545, 55)
        Label3.TabIndex = 6
        Label3.Text = "Ingreso de Credenciales"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(577, 528)
        Controls.Add(Label3)
        Controls.Add(btnIngresar)
        Controls.Add(txtPassword)
        Controls.Add(txtUsuario)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnSalir)
        MaximizeBox = False
        MinimizeBox = False
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Login"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnSalir As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtUsuario As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents btnIngresar As Button
    Friend WithEvents Label3 As Label

End Class
