﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRegistroPaciente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        txtNombre = New TextBox()
        txtApellido = New TextBox()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        txtDireccion = New TextBox()
        txtCelular = New TextBox()
        txtEdad = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        cmbDepartamento = New ComboBox()
        cmbMunicipio = New ComboBox()
        btnGuardar = New Button()
        btnModificar = New Button()
        btnLimpiar = New Button()
        btnEliminar = New Button()
        btnModal = New Button()
        Panel1 = New Panel()
        btnSalir = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(167, 32)
        Label1.Name = "Label1"
        Label1.Size = New Size(675, 65)
        Label1.TabIndex = 0
        Label1.Text = "Datos generales del Paciente"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(50, 203)
        Label2.Name = "Label2"
        Label2.Size = New Size(112, 32)
        Label2.TabIndex = 1
        Label2.Text = "Nombres"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(635, 203)
        Label3.Name = "Label3"
        Label3.Size = New Size(112, 32)
        Label3.TabIndex = 2
        Label3.Text = "Apellidos"
        ' 
        ' txtNombre
        ' 
        txtNombre.Location = New Point(50, 258)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(531, 39)
        txtNombre.TabIndex = 3
        ' 
        ' txtApellido
        ' 
        txtApellido.Location = New Point(635, 258)
        txtApellido.Name = "txtApellido"
        txtApellido.Size = New Size(531, 39)
        txtApellido.TabIndex = 4
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(50, 352)
        Label4.Name = "Label4"
        Label4.Size = New Size(114, 32)
        Label4.TabIndex = 5
        Label4.Text = "Dirección"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(436, 352)
        Label5.Name = "Label5"
        Label5.Size = New Size(88, 32)
        Label5.TabIndex = 6
        Label5.Text = "Celular"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(808, 352)
        Label6.Name = "Label6"
        Label6.Size = New Size(66, 32)
        Label6.TabIndex = 7
        Label6.Text = "Edad"
        ' 
        ' txtDireccion
        ' 
        txtDireccion.Location = New Point(50, 414)
        txtDireccion.Name = "txtDireccion"
        txtDireccion.Size = New Size(349, 39)
        txtDireccion.TabIndex = 8
        ' 
        ' txtCelular
        ' 
        txtCelular.Location = New Point(436, 414)
        txtCelular.Name = "txtCelular"
        txtCelular.Size = New Size(349, 39)
        txtCelular.TabIndex = 9
        ' 
        ' txtEdad
        ' 
        txtEdad.Location = New Point(817, 414)
        txtEdad.Name = "txtEdad"
        txtEdad.Size = New Size(349, 39)
        txtEdad.TabIndex = 10
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(50, 511)
        Label7.Name = "Label7"
        Label7.Size = New Size(168, 32)
        Label7.TabIndex = 11
        Label7.Text = "Departamento"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(635, 511)
        Label8.Name = "Label8"
        Label8.Size = New Size(121, 32)
        Label8.TabIndex = 12
        Label8.Text = "Municipio"
        ' 
        ' cmbDepartamento
        ' 
        cmbDepartamento.FormattingEnabled = True
        cmbDepartamento.Location = New Point(50, 556)
        cmbDepartamento.Name = "cmbDepartamento"
        cmbDepartamento.Size = New Size(531, 40)
        cmbDepartamento.TabIndex = 13
        ' 
        ' cmbMunicipio
        ' 
        cmbMunicipio.FormattingEnabled = True
        cmbMunicipio.Location = New Point(635, 556)
        cmbMunicipio.Name = "cmbMunicipio"
        cmbMunicipio.Size = New Size(531, 40)
        cmbMunicipio.TabIndex = 14
        ' 
        ' btnGuardar
        ' 
        btnGuardar.Location = New Point(1009, 634)
        btnGuardar.Name = "btnGuardar"
        btnGuardar.Size = New Size(157, 55)
        btnGuardar.TabIndex = 15
        btnGuardar.Text = "Guardar"
        btnGuardar.UseVisualStyleBackColor = True
        ' 
        ' btnModificar
        ' 
        btnModificar.Location = New Point(1009, 705)
        btnModificar.Name = "btnModificar"
        btnModificar.Size = New Size(157, 55)
        btnModificar.TabIndex = 16
        btnModificar.Text = "Modificar"
        btnModificar.UseVisualStyleBackColor = True
        ' 
        ' btnLimpiar
        ' 
        btnLimpiar.Location = New Point(829, 634)
        btnLimpiar.Name = "btnLimpiar"
        btnLimpiar.Size = New Size(157, 55)
        btnLimpiar.TabIndex = 17
        btnLimpiar.Text = "Limpiar"
        btnLimpiar.UseVisualStyleBackColor = True
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Location = New Point(647, 634)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(157, 55)
        btnEliminar.TabIndex = 18
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnModal
        ' 
        btnModal.Location = New Point(167, 634)
        btnModal.Name = "btnModal"
        btnModal.Size = New Size(216, 55)
        btnModal.TabIndex = 19
        btnModal.Text = "Registrar Peso"
        btnModal.UseVisualStyleBackColor = True
        ' 
        ' Panel1
        ' 
        Panel1.Location = New Point(95, 825)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(728, 265)
        Panel1.TabIndex = 20
        ' 
        ' btnSalir
        ' 
        btnSalir.Location = New Point(404, 634)
        btnSalir.Name = "btnSalir"
        btnSalir.Size = New Size(216, 55)
        btnSalir.TabIndex = 21
        btnSalir.Text = "Salir"
        btnSalir.UseVisualStyleBackColor = True
        ' 
        ' frmRegistroPaciente
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1219, 1223)
        Controls.Add(btnSalir)
        Controls.Add(Panel1)
        Controls.Add(btnModal)
        Controls.Add(btnEliminar)
        Controls.Add(btnLimpiar)
        Controls.Add(btnModificar)
        Controls.Add(btnGuardar)
        Controls.Add(cmbMunicipio)
        Controls.Add(cmbDepartamento)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(txtEdad)
        Controls.Add(txtCelular)
        Controls.Add(txtDireccion)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(txtApellido)
        Controls.Add(txtNombre)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "frmRegistroPaciente"
        Text = "frmRegistroPaciente"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents txtApellido As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtDireccion As TextBox
    Friend WithEvents txtCelular As TextBox
    Friend WithEvents txtEdad As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents cmbDepartamento As ComboBox
    Friend WithEvents cmbMunicipio As ComboBox
    Friend WithEvents btnGuardar As Button
    Friend WithEvents btnModificar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnModal As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btnSalir As Button
End Class
