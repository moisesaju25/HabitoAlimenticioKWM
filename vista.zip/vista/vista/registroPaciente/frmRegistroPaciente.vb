﻿Public Class frmRegistroPaciente
    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
        frmConsultaPaciente.Show()
    End Sub
End Class