﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConsultaPaciente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        TextBox1 = New TextBox()
        Label2 = New Label()
        btnBuscar = New Button()
        dgridPacientes = New DataGridView()
        btnNuevo = New Button()
        btnSalir = New Button()
        btnRecargar = New Button()
        CType(dgridPacientes, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 16.125F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(544, 8)
        Label1.Name = "Label1"
        Label1.Size = New Size(464, 59)
        Label1.TabIndex = 0
        Label1.Text = "Consulta de Pacientes"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(31, 209)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(769, 39)
        TextBox1.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(31, 150)
        Label2.Name = "Label2"
        Label2.Size = New Size(406, 32)
        Label2.TabIndex = 2
        Label2.Text = "Ingrese el dato del paciente a buscar"
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Location = New Point(806, 209)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(207, 39)
        btnBuscar.TabIndex = 3
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' dgridPacientes
        ' 
        dgridPacientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgridPacientes.Location = New Point(30, 308)
        dgridPacientes.Name = "dgridPacientes"
        dgridPacientes.RowHeadersWidth = 82
        dgridPacientes.Size = New Size(1365, 468)
        dgridPacientes.TabIndex = 4
        ' 
        ' btnNuevo
        ' 
        btnNuevo.Location = New Point(1188, 263)
        btnNuevo.Name = "btnNuevo"
        btnNuevo.Size = New Size(207, 39)
        btnNuevo.TabIndex = 5
        btnNuevo.Text = "Nuevo"
        btnNuevo.UseVisualStyleBackColor = True
        ' 
        ' btnSalir
        ' 
        btnSalir.Location = New Point(975, 263)
        btnSalir.Name = "btnSalir"
        btnSalir.Size = New Size(207, 39)
        btnSalir.TabIndex = 6
        btnSalir.Text = "Salir"
        btnSalir.UseVisualStyleBackColor = True
        ' 
        ' btnRecargar
        ' 
        btnRecargar.Location = New Point(739, 263)
        btnRecargar.Name = "btnRecargar"
        btnRecargar.Size = New Size(207, 39)
        btnRecargar.TabIndex = 7
        btnRecargar.Text = "Recargar"
        btnRecargar.UseVisualStyleBackColor = True
        ' 
        ' frmConsultaPaciente
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1425, 806)
        Controls.Add(btnRecargar)
        Controls.Add(btnSalir)
        Controls.Add(btnNuevo)
        Controls.Add(dgridPacientes)
        Controls.Add(btnBuscar)
        Controls.Add(Label2)
        Controls.Add(TextBox1)
        Controls.Add(Label1)
        Name = "frmConsultaPaciente"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Consulta Paciente"
        CType(dgridPacientes, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnBuscar As Button
    Friend WithEvents dgridPacientes As DataGridView
    Friend WithEvents btnNuevo As Button
    Friend WithEvents btnSalir As Button
    Friend WithEvents btnRecargar As Button
End Class
