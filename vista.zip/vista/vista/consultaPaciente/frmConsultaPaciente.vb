﻿Imports MySql.Data.MySqlClient

Public Class frmConsultaPaciente
    Private Sub btnNuevo_Click(sender As Object, e As EventArgs) Handles btnNuevo.Click
        Me.Close()
        frmRegistroPaciente.Show()
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Close()
    End Sub

    Private Sub btnRecargar_Click(sender As Object, e As EventArgs) Handles btnRecargar.Click
        Dim vSql = "select * from persona"
        'Dim vCmd As MySqlCommand = New MySqlCommand(vSql, vConn)

        'D'im vReader As MySqlDataReader = vCmd.ExecuteReader

        'While (vReader.Read)
        'dgridPacientes.Rows.Add(vReader.GetString(0))
        'End While
    End Sub
End Class