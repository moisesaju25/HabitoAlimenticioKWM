﻿Public Class Usuario
    Dim idUsuario As Integer
    Dim nombres, apellidos, usuario, clave, estado As String
End Class
