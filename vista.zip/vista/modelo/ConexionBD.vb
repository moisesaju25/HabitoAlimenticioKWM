﻿Imports MySql.Data.MySqlClient

Public Module Conexion
    'Public Class ConexionBD
    Public ConexionMySQL As MySqlConnection
    Public Comando As MySqlCommand
    Public adaptador As MySqlDataAdapter

    Public da As MySqlDataAdapter
    Public ds As DataSet

    'Private servidor = "localhost", usuario = "habitos", password = "habitos" As String


    Public cadenaConexion As String = "Server=localhost;Port=3306;Database=habitos_alimenticios;Uid=habitos;Pwd=habitos;"
    'a travez de una funcion abrimo una conección a la base de datos
    Public Sub AbrirConexion()
        Try
            ConexionMySQL = New MySqlConnection(cadenaConexion)
            ConexionMySQL.Open()
        Catch ex As Exception
            Err.ToString()
        End Try
    End Sub
    'a travez de una funcion cerramos una conección a la base de datos
    Public Sub cerrarConexion()
        Try
            If (ConexionMySQL.State = ConnectionState.Open) Then
                ConexionMySQL.Close()
            End If
        Catch ex As Exception
            Err.ToString()
        End Try
    End Sub
    'End Class
End Module