﻿Imports MySql.Data.MySqlClient
Public Class Configuracion
    Private Shared _FECHASERVIDOR As Date
    Public Shared Property FECHASERVIDOR As Date
        Get
            Return _FECHASERVIDOR
        End Get
        Set(ByVal value As Date)
            _FECHASERVIDOR = value
        End Set
    End Property

    Public Shared Sub ObtenerFechaServidor()
        Try
            AbrirConexion()
            If ConexionMySQL.State = ConnectionState.Closed Then
                ConexionMySQL.Open()
            End If

            adaptador = New MySqlDataAdapter("SELECT NOW() AS CurrentDateTime", ConexionMySQL)
            ds = New DataSet
            adaptador.Fill(ds)

            If ds.Tables(0).Rows.Count > 0 Then
                FECHASERVIDOR = ds.Tables(0).Rows(0).Item(0)
            Else
                FECHASERVIDOR = Today.Date
            End If

            ConexionMySQL.Close()

        Catch ex As Exception
            Console.WriteLine(Err.Description)
        End Try

    End Sub
End Class
